<?php
namespace Vimeo\Exceptions;

/**
 * VimeoException class for general failures.
 */
class VimeoException extends \Exception implements ExceptionInterface
{
}
