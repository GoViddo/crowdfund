<?php

error_reporting(0);

//autoloading the packages in the vendor folder.
require "vendor/autoload.php";

//setting up braintree credentials
Braintree_Configuration::environment('sandbox');
Braintree_Configuration::merchantId('x8wcczgwvtqgmk24');
Braintree_Configuration::publicKey('cd59gk5t664byr28');
Braintree_Configuration::privateKey('e2009866a45001d73ed3a7d575f0adc7');

//Booting Done.