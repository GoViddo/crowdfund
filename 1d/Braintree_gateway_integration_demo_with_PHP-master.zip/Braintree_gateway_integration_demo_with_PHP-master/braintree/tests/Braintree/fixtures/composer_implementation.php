<?php

require_once __DIR__ . '/../../../vendor/autoload.php';

class_exists("Braintree_Modification");
